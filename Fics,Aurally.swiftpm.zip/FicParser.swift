import Foundation
import UIKit

// MARK: - Models

enum SegmentKind: String, CaseIterable, Hashable {
    case narration, dialogue, thought

    var label: String {
        switch self {
        case .narration: return "Narration"
        case .dialogue: return "Dialogue"
        case .thought: return "Thoughts"
        }
    }
}

struct Segment: Identifiable, Equatable {
    let id: Int          // always equals the index in the segments array
    let kind: SegmentKind
    let text: String     // exactly what is spoken AND displayed (no markers)
    let paragraph: Int
}

// MARK: - Shared helper

private func nextIndex(of ch: Character, in chars: [Character], after i: Int) -> Int? {
    var j = i + 1
    while j < chars.count {
        if chars[j] == ch { return j }
        j += 1
    }
    return nil
}

// MARK: - Text cleaning

enum TextCleaner {

    /// Full pipeline for arbitrary pasted text.
    static func prepare(_ raw: String) -> String {
        let t = looksLikeHTML(raw) ? fromHTML(raw) : raw
        return normalize(t)
    }

    static func looksLikeHTML(_ s: String) -> Bool {
        guard s.contains("<"),
              let re = try? NSRegularExpression(
                pattern: "</?(p|div|br|em|i|span|b|strong|a|h[1-6]|ul|ol|li|hr|body|html)\\b[^>]*>",
                options: [.caseInsensitive])
        else { return false }
        let range = NSRange(s.startIndex..<s.endIndex, in: s)
        return re.firstMatch(in: s, options: [], range: range) != nil
    }

    /// Whitespace cleanup + Markdown-style _italics_ converted to *italics*.
    static func normalize(_ s: String) -> String {
        var t = s.replacingOccurrences(of: "\r\n", with: "\n")
        t = t.replacingOccurrences(of: "\r", with: "\n")
        t = t.replacingOccurrences(of: "\u{00A0}", with: " ")
        t = t.replacingOccurrences(of: "\u{FEFF}", with: "")
        t = t.replacingOccurrences(of: "\u{2028}", with: "\n")
        t = t.replacingOccurrences(of: "\u{2029}", with: "\n")
        t = t.replacingOccurrences(of: "\t", with: " ")

        if let re = try? NSRegularExpression(
            pattern: "(?<![\\p{L}\\p{N}_])_([^_\\n]+)_(?![\\p{L}\\p{N}_])") {
            let range = NSRange(t.startIndex..<t.endIndex, in: t)
            t = re.stringByReplacingMatches(in: t, options: [], range: range, withTemplate: "*$1*")
        }
        return t.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    // MARK: HTML -> text (hand-written, no WebKit, no NSAttributedString)

    private static let entities: [String: String] = [
        "amp": "&", "lt": "<", "gt": ">", "quot": "\"", "apos": "'",
        "nbsp": " ", "rsquo": "\u{2019}", "lsquo": "\u{2018}",
        "ldquo": "\u{201C}", "rdquo": "\u{201D}",
        "mdash": "\u{2014}", "ndash": "\u{2013}", "hellip": "\u{2026}"
    ]

    static func fromHTML(_ html: String) -> String {
        let chars = Array(html)
        var out = ""
        var i = 0
        var spanStack: [Bool] = []     // true = this <span> is italic
        var skipping: String? = nil    // inside <script> / <style>

        while i < chars.count {
            let c = chars[i]

            if c == "<" {
                let next: Character = (i + 1 < chars.count) ? chars[i + 1] : " "
                let looksLikeTag = next.isLetter || next == "/" || next == "!"

                if looksLikeTag {
                    // HTML comment
                    if startsWith(chars, at: i, "<!--") {
                        if let end = indexOf(chars, "-->", from: i + 4) { i = end + 3 } else { i = chars.count }
                        continue
                    }
                    if let close = nextIndex(of: ">", in: chars, after: i) {
                        let inner = String(chars[(i + 1)..<close])
                        i = close + 1

                        let isClosing = inner.hasPrefix("/")
                        let body = isClosing ? String(inner.dropFirst()) : inner
                        let name = String(body.prefix(while: { $0.isLetter || $0.isNumber })).lowercased()

                        if let skip = skipping {
                            if isClosing && name == skip { skipping = nil }
                            continue
                        }

                        switch name {
                        case "script", "style":
                            if !isClosing { skipping = name }
                        case "i", "em", "cite":
                            out.append("*")
                        case "br":
                            out.append("\n")
                        case "hr":
                            out.append("\n***\n")
                        case "p", "div", "h1", "h2", "h3", "h4", "h5", "h6",
                             "li", "tr", "blockquote", "ul", "ol", "table":
                            out.append("\n")
                        case "span":
                            if isClosing {
                                if spanStack.popLast() == true { out.append("*") }
                            } else {
                                let low = inner.lowercased().replacingOccurrences(of: " ", with: "")
                                let italic = low.contains("font-style:italic")
                                spanStack.append(italic)
                                if italic { out.append("*") }
                            }
                        default:
                            break
                        }
                        continue
                    }
                }
                // Not a tag: literal "<"
                if skipping == nil { out.append(c) }
                i += 1
                continue
            }

            if skipping != nil { i += 1; continue }

            if c == "&" {
                let (decoded, consumed) = decodeEntity(chars, at: i)
                out.append(decoded)
                i += consumed
                continue
            }

            // In HTML, raw newlines/tabs are just spaces. Real breaks come from tags.
            if c.isNewline || c == "\t" {
                out.append(" ")
            } else {
                out.append(c)
            }
            i += 1
        }
        return out
    }

    private static func decodeEntity(_ chars: [Character], at i: Int) -> (String, Int) {
        var j = i + 1
        var name = ""
        while j < chars.count, j - i <= 10, chars[j] != ";", chars[j] != "&", !chars[j].isWhitespace {
            name.append(chars[j])
            j += 1
        }
        guard j < chars.count, chars[j] == ";", !name.isEmpty else { return ("&", 1) }
        let consumed = j - i + 1

        if name.hasPrefix("#") {
            let digits = name.dropFirst()
            let value: UInt32?
            if digits.hasPrefix("x") || digits.hasPrefix("X") {
                value = UInt32(digits.dropFirst(), radix: 16)
            } else {
                value = UInt32(digits, radix: 10)
            }
            if let v = value, let scalar = Unicode.Scalar(v) {
                return (String(Character(scalar)), consumed)
            }
            return ("", consumed)
        }
        if let rep = entities[name] { return (rep, consumed) }
        return ("&", 1)
    }

    private static func startsWith(_ chars: [Character], at i: Int, _ s: String) -> Bool {
        let t = Array(s)
        guard i + t.count <= chars.count else { return false }
        for k in 0..<t.count where chars[i + k] != t[k] { return false }
        return true
    }

    private static func indexOf(_ chars: [Character], _ s: String, from: Int) -> Int? {
        var k = from
        while k < chars.count {
            if startsWith(chars, at: k, s) { return k }
            k += 1
        }
        return nil
    }
}

// MARK: - Clipboard

enum Clipboard {
    /// Prefers the rich HTML on the pasteboard (so italics survive as *asterisks*),
    /// falls back to plain text. Returns already-prepared text.
    static func read() -> String? {
        let pb = UIPasteboard.general

        if let data = pb.data(forPasteboardType: "public.html"), let html = decode(data) {
            let text = TextCleaner.normalize(TextCleaner.fromHTML(html))
            if text.contains(where: { $0.isLetter }) { return text }
        }
        if let plain = pb.string {
            let text = TextCleaner.prepare(plain)
            if text.contains(where: { $0.isLetter }) { return text }
        }
        return nil
    }

    private static func decode(_ data: Data) -> String? {
        // UTF-16 data contains zero bytes very early; UTF-8 HTML does not.
        if data.prefix(64).contains(0) { return String(data: data, encoding: .utf16) }
        return String(data: data, encoding: .utf8)
    }
}

// MARK: - Parser

enum FicParser {
    static let maxChunk = 380   // keeps each utterance short and reliable

    static func parse(_ text: String) -> [Segment] {
        var result: [Segment] = []
        var paragraph = 0

        for line in text.components(separatedBy: "\n") {
            var trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty || isSceneBreak(trimmed) { continue }

            // **bold** markers are not meaningful for speech.
            trimmed = trimmed.replacingOccurrences(of: "**", with: "")

            var added = false
            for (kind, raw) in splitParagraph(trimmed) {
                let cleaned = raw.trimmingCharacters(in: .whitespacesAndNewlines)
                // Skip pieces with nothing speakable (e.g. just "...")
                guard cleaned.contains(where: { $0.isLetter || $0.isNumber }) else { continue }
                for piece in chunk(cleaned) {
                    result.append(Segment(id: result.count, kind: kind, text: piece, paragraph: paragraph))
                    added = true
                }
            }
            if added { paragraph += 1 }
        }
        return result
    }

    private static func isSceneBreak(_ s: String) -> Bool {
        let allowed: Set<Character> = ["*", "-", "\u{2013}", "\u{2014}", "_", "~", "=", "#", ".", "\u{2022}", " "]
        return s.count >= 3 && s.allSatisfy { allowed.contains($0) }
    }

    /// One paragraph -> ordered (kind, text) pieces.
    /// Rules:
    ///  - "…" or “…” = dialogue (needs a closer in the same paragraph)
    ///  - *…* = thought
    ///  - an opening quote with no closer at the START of a paragraph = dialogue to paragraph end
    ///    (multi-paragraph speech)
    ///  - any other unmatched quote/asterisk is dropped, never spoken, never crashes
    ///  - asterisks inside dialogue are stripped (emphasis only)
    private static func splitParagraph(_ line: String) -> [(SegmentKind, String)] {
        let chars = Array(line)
        var parts: [(SegmentKind, String)] = []
        var buffer = ""
        let firstContent = chars.firstIndex(where: { !$0.isWhitespace }) ?? 0

        func flush() {
            if !buffer.isEmpty {
                parts.append((.narration, buffer))
                buffer = ""
            }
        }
        func strip(_ s: String) -> String {
            s.replacingOccurrences(of: "*", with: "")
        }

        var i = 0
        while i < chars.count {
            let c = chars[i]
            switch c {
            case "\"", "\u{201C}":
                let closer: Character = (c == "\"") ? "\"" : "\u{201D}"
                if let end = nextIndex(of: closer, in: chars, after: i) {
                    flush()
                    parts.append((.dialogue, strip(String(chars[(i + 1)..<end]))))
                    i = end + 1
                } else if i == firstContent {
                    flush()
                    parts.append((.dialogue, strip(String(chars[(i + 1)...]))))
                    i = chars.count
                } else {
                    i += 1
                }
            case "*":
                if let end = nextIndex(of: "*", in: chars, after: i) {
                    flush()
                    parts.append((.thought, String(chars[(i + 1)..<end])))
                    i = end + 1
                } else {
                    i += 1
                }
            default:
                buffer.append(c)
                i += 1
            }
        }
        flush()
        return parts
    }

    private static func chunk(_ text: String) -> [String] {
        guard text.count > maxChunk else { return [text] }
        var out: [String] = []
        var current = ""
        text.enumerateSubstrings(in: text.startIndex..<text.endIndex, options: .bySentences) { sub, _, _, _ in
            guard let s = sub?.trimmingCharacters(in: .whitespacesAndNewlines), !s.isEmpty else { return }
            if !current.isEmpty && current.count + s.count + 1 > maxChunk {
                out.append(current)
                current = ""
            }
            current = current.isEmpty ? s : current + " " + s
        }
        if !current.isEmpty { out.append(current) }
        return out.isEmpty ? [text] : out
    }
}
