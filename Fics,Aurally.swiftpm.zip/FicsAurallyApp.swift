import SwiftUI

// Only ONE @main may exist in the project.
// Delete or empty the default MyApp.swift that Swift Playgrounds created.
@main
struct FicsAurallyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
