import AVFoundation
import SwiftUI

// MARK: - Small support types

struct SpeedOption {
    let label: String
    let rate: Float   // AVSpeechUtterance rate (0...1, default 0.5); labels are approximate
}

struct Accent: Identifiable {
    let id: String    // BCP-47 code, e.g. "en-GB"
    let name: String
}

/// Saves the last loaded text to the app's Documents folder.
enum Library {
    private static var url: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("fics_last.txt")
    }
    static func save(_ text: String) { try? text.write(to: url, atomically: true, encoding: .utf8) }
    static func load() -> String? { try? String(contentsOf: url, encoding: .utf8) }
}

// MARK: - Engine

@MainActor
final class SpeechEngine: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {

    enum PlayState { case idle, playing, paused }

    static let speedOptions: [SpeedOption] = [
        SpeedOption(label: "0.75x", rate: 0.44),
        SpeedOption(label: "1x", rate: 0.50),
        SpeedOption(label: "1.25x", rate: 0.55),
        SpeedOption(label: "1.5x", rate: 0.60),
        SpeedOption(label: "1.75x", rate: 0.65)
    ]

    static let accents: [Accent] = [
        Accent(id: "en-US", name: "US English"),
        Accent(id: "en-GB", name: "UK English"),
        Accent(id: "en-AU", name: "Australian English"),
        Accent(id: "en-IE", name: "Irish English"),
        Accent(id: "en-ZA", name: "South African English"),
        Accent(id: "en-IN", name: "Indian English")
    ]

    @Published private(set) var segments: [Segment] = []
    @Published private(set) var currentIndex = 0
    @Published private(set) var state: PlayState = .idle
    @Published private(set) var highlight: NSRange?

    @Published var speedIndex = 1 {
        didSet {
            UserDefaults.standard.set(speedIndex, forKey: "fics.speed")
            if state == .playing { speakCurrent() }   // apply immediately
        }
    }

    @Published var accent: [SegmentKind: String] = [
        .narration: "en-US",
        .dialogue: "en-GB",
        .thought: "en-AU"
    ] {
        didSet {
            var raw: [String: String] = [:]
            for (kind, code) in accent { raw[kind.rawValue] = code }
            UserDefaults.standard.set(raw, forKey: "fics.accents")
        }
    }

    private let synth = AVSpeechSynthesizer()
    private var currentUtterance: AVSpeechUtterance?
    private var currentID: ObjectIdentifier?
    private var voiceCache: [String: AVSpeechSynthesisVoice] = [:]
    private var finishedAtEnd = false

    // MARK: Lifecycle

    override init() {
        super.init()
        synth.delegate = self

        let d = UserDefaults.standard
        if d.object(forKey: "fics.speed") != nil {
            speedIndex = min(max(d.integer(forKey: "fics.speed"), 0), Self.speedOptions.count - 1)
        }
        if let saved = d.dictionary(forKey: "fics.accents") as? [String: String] {
            for (key, code) in saved {
                if let kind = SegmentKind(rawValue: key) { accent[kind] = code }
            }
        }
        if let text = Library.load(), !text.isEmpty {
            segments = FicParser.parse(text)
            currentIndex = min(max(d.integer(forKey: "fics.index"), 0), max(segments.count - 1, 0))
        }
    }

    /// Expects text that went through TextCleaner.prepare (Clipboard.read already does that).
    func load(_ prepared: String) {
        stop()
        segments = FicParser.parse(prepared)
        currentIndex = 0
        finishedAtEnd = false
        UserDefaults.standard.set(0, forKey: "fics.index")
        Library.save(prepared)
    }

    // MARK: Transport

    func togglePlay() {
        guard !segments.isEmpty else { return }
        switch state {
        case .idle:
            if finishedAtEnd { currentIndex = 0; finishedAtEnd = false }
            speakCurrent()
        case .playing:
            synth.pauseSpeaking(at: .word)
            state = .paused
        case .paused:
            activateSession()
            synth.continueSpeaking()
            state = .playing
        }
    }

    func play(from index: Int) {
        guard segments.indices.contains(index) else { return }
        currentIndex = index
        finishedAtEnd = false
        speakCurrent()
    }

    func next() {
        guard currentIndex + 1 < segments.count else { return }
        play(from: currentIndex + 1)
    }

    func previous() {
        play(from: max(currentIndex - 1, 0))
    }

    func stop() {
        currentID = nil
        currentUtterance = nil
        synth.stopSpeaking(at: .immediate)
        state = .idle
        highlight = nil
    }

    func preview(_ kind: SegmentKind) {
        stop()
        let sample: String
        switch kind {
        case .narration: sample = "The rain kept falling over the quiet town."
        case .dialogue: sample = "I did not expect to see you here tonight."
        case .thought: sample = "Please don't let him notice how nervous I am."
        }
        let seg = Segment(id: -1, kind: kind, text: sample, paragraph: 0)
        activateSession()
        synth.speak(makeUtterance(for: seg, pause: 0))   // currentID stays nil: no auto-advance
    }

    // MARK: Speaking

    private func speakCurrent() {
        guard segments.indices.contains(currentIndex) else { stop(); return }
        let seg = segments[currentIndex]
        UserDefaults.standard.set(currentIndex, forKey: "fics.index")

        // Invalidate callbacks from whatever was speaking before.
        currentID = nil
        synth.stopSpeaking(at: .immediate)

        let nextIsNewParagraph = segments.indices.contains(currentIndex + 1)
            && segments[currentIndex + 1].paragraph != seg.paragraph
        let utterance = makeUtterance(for: seg, pause: nextIsNewParagraph ? 0.35 : 0.08)

        currentUtterance = utterance
        currentID = ObjectIdentifier(utterance)
        highlight = nil
        state = .playing
        activateSession()
        synth.speak(utterance)
    }

    private func makeUtterance(for seg: Segment, pause: TimeInterval) -> AVSpeechUtterance {
        let u = AVSpeechUtterance(string: seg.text)
        u.voice = voice(for: accent[seg.kind] ?? "en-US")
        u.rate = Self.speedOptions[min(max(speedIndex, 0), Self.speedOptions.count - 1)].rate
        u.preUtteranceDelay = 0
        u.postUtteranceDelay = pause
        switch seg.kind {
        case .narration:
            u.pitchMultiplier = 1.0
            u.volume = 1.0
        case .dialogue:
            u.pitchMultiplier = 1.08
            u.volume = 1.0
        case .thought:
            u.pitchMultiplier = 0.9
            u.volume = 0.85
        }
        return u
    }

    private func voice(for language: String) -> AVSpeechSynthesisVoice? {
        if let cached = voiceCache[language] { return cached }
        let matches = AVSpeechSynthesisVoice.speechVoices().filter {
            $0.language == language && !$0.identifier.contains("speech.synthesis.voice")   // skip novelty voices
        }
        let best = matches.max { $0.quality.rawValue < $1.quality.rawValue }
            ?? AVSpeechSynthesisVoice(language: language)
        if let best { voiceCache[language] = best }
        return best
    }

    private func activateSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .spokenAudio)
        try? session.setActive(true)
    }

    // MARK: Delegate (callbacks hop to the main actor with Sendable values only)

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer,
                                       didFinish utterance: AVSpeechUtterance) {
        let id = ObjectIdentifier(utterance)
        Task { @MainActor in self.handleFinish(id) }
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer,
                                       willSpeakRangeOfSpeechString characterRange: NSRange,
                                       utterance: AVSpeechUtterance) {
        let id = ObjectIdentifier(utterance)
        Task { @MainActor in self.handleRange(characterRange, id: id) }
    }

    private func handleFinish(_ id: ObjectIdentifier) {
        guard id == currentID, state == .playing else { return }
        highlight = nil
        if currentIndex + 1 < segments.count {
            currentIndex += 1
            speakCurrent()
        } else {
            currentID = nil
            currentUtterance = nil
            state = .idle
            finishedAtEnd = true
        }
    }

    private func handleRange(_ range: NSRange, id: ObjectIdentifier) {
        guard id == currentID else { return }
        highlight = range
    }
}
