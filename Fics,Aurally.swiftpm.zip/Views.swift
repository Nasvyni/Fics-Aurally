import SwiftUI

// NOTE: no #Preview / PreviewProvider anywhere on purpose.
// Previews are the main source of cache crashes in Swift Playgrounds; run the app instead.

// MARK: - Main screen

struct ContentView: View {
    @StateObject private var engine = SpeechEngine()
    @State private var showImport = false
    @State private var showSettings = false

    var body: some View {
        NavigationStack {
            Group {
                if engine.segments.isEmpty {
                    emptyState
                } else {
                    reader
                }
            }
            .navigationTitle("Fics,Aurally")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    Button { showImport = true } label: { Image(systemName: "doc.on.clipboard") }
                    Button { showSettings = true } label: { Image(systemName: "slider.horizontal.3") }
                }
            }
            .safeAreaInset(edge: .bottom) {
                if !engine.segments.isEmpty {
                    ControlBar(engine: engine)
                }
            }
        }
        .sheet(isPresented: $showImport) {
            ImportView { prepared in engine.load(prepared) }
        }
        .sheet(isPresented: $showSettings) {
            SettingsView(engine: engine)
        }
    }

    private var emptyState: some View {
        VStack(spacing: 16) {
            Image(systemName: "waveform.and.person.filled")
                .font(.system(size: 56))
                .foregroundColor(.secondary)
            Text(verbatim: "Copy a chapter in Safari, then import it.")
                .foregroundColor(.secondary)
            Button("Import Text") { showImport = true }
                .buttonStyle(.borderedProminent)
        }
        .padding()
    }

    private var reader: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 4) {
                    ForEach(engine.segments) { seg in
                        SegmentRow(
                            segment: seg,
                            isCurrent: seg.id == engine.currentIndex,
                            highlight: seg.id == engine.currentIndex ? engine.highlight : nil,
                            startsParagraph: seg.id == 0 || engine.segments[seg.id - 1].paragraph != seg.paragraph
                        )
                        .id(seg.id)
                        .onTapGesture { engine.play(from: seg.id) }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 12)
            }
            .onChange(of: engine.currentIndex) { index in
                withAnimation { proxy.scrollTo(index, anchor: .center) }
            }
        }
    }
}

// MARK: - One spoken segment

struct SegmentRow: View {
    let segment: Segment
    let isCurrent: Bool
    let highlight: NSRange?
    let startsParagraph: Bool

    var body: some View {
        content
            .font(font)
            .foregroundColor(color)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 6)
            .padding(.horizontal, 10)
            .background(isCurrent ? Color.accentColor.opacity(0.15) : Color.clear)
            .cornerRadius(8)
            .padding(.top, startsParagraph ? 10 : 0)
            .contentShape(Rectangle())
    }

    /// Word-level highlight inside the current segment (colour only, so layout never shifts).
    private var content: Text {
        let s = segment.text
        if let nsRange = highlight, let r = Range(nsRange, in: s) {
            return Text(String(s[..<r.lowerBound]))
                + Text(String(s[r])).foregroundColor(.orange)
                + Text(String(s[r.upperBound...]))
        }
        return Text(s)
    }

    private var font: Font {
        let base = Font.system(.body, design: .serif)
        return segment.kind == .thought ? base.italic() : base
    }

    private var color: Color {
        switch segment.kind {
        case .narration: return .primary
        case .dialogue: return .blue
        case .thought: return .purple
        }
    }
}

// MARK: - Bottom controls

struct ControlBar: View {
    @ObservedObject var engine: SpeechEngine

    var body: some View {
        VStack(spacing: 8) {
            ProgressView(value: Double(engine.currentIndex + 1),
                         total: Double(max(engine.segments.count, 1)))

            HStack(spacing: 28) {
                Button { engine.previous() } label: {
                    Image(systemName: "backward.fill").font(.title2)
                }
                Button { engine.togglePlay() } label: {
                    Image(systemName: engine.state == .playing ? "pause.circle.fill" : "play.circle.fill")
                        .font(.system(size: 46))
                }
                Button { engine.next() } label: {
                    Image(systemName: "forward.fill").font(.title2)
                }
                Picker("Speed", selection: $engine.speedIndex) {
                    ForEach(SpeechEngine.speedOptions.indices, id: \.self) { i in
                        Text(SpeechEngine.speedOptions[i].label).tag(i)
                    }
                }
                .pickerStyle(.menu)
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 10)
        .background(.bar)
    }
}

// MARK: - Import sheet

struct ImportView: View {
    @Environment(\.dismiss) private var dismiss
    let onLoad: (String) -> Void

    @State private var draft = ""
    @State private var message: String?

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 12) {
                Button {
                    if let text = Clipboard.read() {
                        onLoad(text)
                        dismiss()
                    } else {
                        message = "Clipboard is empty or has no readable text."
                    }
                } label: {
                    Label("Paste from Clipboard & Load", systemImage: "doc.on.clipboard")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)

                Text(verbatim: "Copying from Safari keeps italics (they become *asterisks*). Typing or pasting into the box below is plain text, so italics are lost.")
                    .font(.footnote)
                    .foregroundColor(.secondary)

                TextEditor(text: $draft)
                    .frame(minHeight: 200)
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.secondary.opacity(0.4)))

                Button("Load Text Above") {
                    onLoad(TextCleaner.prepare(draft))
                    dismiss()
                }
                .disabled(draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                if let msg = message {
                    Text(msg).font(.footnote).foregroundColor(.red)
                }
                Spacer()
            }
            .padding()
            .navigationTitle("Import Text")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }
}

// MARK: - Settings sheet

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var engine: SpeechEngine

    var body: some View {
        NavigationStack {
            Form {
                ForEach(SegmentKind.allCases, id: \.self) { kind in
                    Section(kind.label) {
                        Picker("Accent", selection: Binding(
                            get: { engine.accent[kind] ?? "en-US" },
                            set: { engine.accent[kind] = $0 }
                        )) {
                            ForEach(SpeechEngine.accents) { accent in
                                Text(accent.name).tag(accent.id)
                            }
                        }
                        Button("Preview voice") { engine.preview(kind) }
                    }
                }
                Section {
                    Text(verbatim: "Better voices: Settings > Accessibility > Spoken Content > Voices. Download Enhanced or Premium versions for each accent; the app picks the best installed one automatically.")
                        .font(.footnote)
                }
            }
            .navigationTitle("Voices")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}
